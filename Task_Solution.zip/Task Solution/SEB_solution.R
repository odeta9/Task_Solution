# Task for Junior Quantitative Data Analyst in Credit Risk Model Validation

# 1. INPUTS 
INPUT_ZIP <- "Data.zip"
OUTPUT_FOLDER <- "SEB_results"
AS_OF_DATE <- as.Date("2026-01-01") # Assumed observation cutoff
LATE_TYPES <- c("cashflows", "sale", "costs") # Extend recoveries/costs, not interest

args <- if (sys.nframe() == 0L) commandArgs(trailingOnly = TRUE) else character()
if (length(args) >= 1) INPUT_ZIP <- args[1]
if (length(args) >= 2) OUTPUT_FOLDER <- args[2]
stopifnot(file.exists(INPUT_ZIP))
dir.create(OUTPUT_FOLDER, recursive = TRUE, showWarnings = FALSE)
invisible(Sys.setlocale("LC_COLLATE", "C"))

tables <- c("contracts", "defaults", "collateral", "cashflows", "sale",
            "costs", "interest", "write_off")
raw <- list()
for (name in tables) {
  raw[[name]] <- read.csv(unz(INPUT_ZIP, paste0("Data/", name, ".csv")),
                         colClasses = "character", na.strings = c("NA", ""))
}
contracts <- raw$contracts
collateral <- raw$collateral
# Standardized defaults are joined and calculated below, then exported
standardized_defaults <- raw$defaults
standardized_defaults$source_row <- seq_len(nrow(standardized_defaults))
contracts$source_row <- seq_len(nrow(contracts))
collateral$source_row <- seq_len(nrow(collateral))

# Quality-check table
check <- function(table, rule, bad, action, detail) {
  stopifnot(length(bad) == nrow(raw[[table]]))
  bad[is.na(bad)] <- TRUE
  quality[nrow(quality) + 1, ] <<- list(table, rule, sum(bad), length(bad),
                                     100 * mean(bad), action, detail)
}
quality <- data.frame(table = character(), rule = character(), count = integer(),
                      total_rows = integer(), share_pct = numeric(), action = character(), detail = character())
valid_id <- function(x, pattern) !is.na(x) & grepl(pattern, x)
parse_number <- function(x) {
  y <- suppressWarnings(as.numeric(x))
  y[!is.finite(y)] <- NA_real_  # Text, NaN and Inf are unavailable, never zero.
  y
}
parse_date <- function(x) {
  y <- suppressWarnings(as.Date(x, format = "%Y-%m-%d"))
  bad <- is.na(x) | is.na(y) | format(y, "%Y-%m-%d") != x
  y[which(bad)] <- as.Date(NA)
  y
}
for (name in tables) {
  x <- raw[[name]]
  if ("AR_ID" %in% names(x)) check(name, "Invalid or missing arrangement ID",
    !valid_id(x$AR_ID, "^[0-9]{8}$"),
    if (name == "sale") "Standardize" else "Exclude from analysis",
    if (name == "sale") "Remove two surplus zeros only with a reference match" else "Unresolved IDs stay unassigned")
  if ("IP_ID" %in% names(x)) check(name, "Invalid or missing borrower ID",
    !valid_id(x$IP_ID, "^[A-Z]{3}[0-9]{3}$"), "Exclude from analysis", "Do not guess an identifier")
}

# 2. STANDARDIZED DATA 
candidate <- gsub("_", "", collateral$GU_ID, fixed = TRUE)
fix <- valid_id(collateral$GU_ID, "^[A-Z]_[0-9]{6}$") & candidate %in% contracts$GU_ID
collateral$GU_ID_original <- collateral$GU_ID
repair_examples <- data.frame(file = "collateral", corrected_rows = sum(fix),
  original = collateral$GU_ID[fix][1], corrected = candidate[fix][1])
check("collateral", "Invalid guarantee format", !valid_id(collateral$GU_ID, "^[A-Z][0-9]{6}$"),
      "Standardize", "Remove the underscore only with a unique reference match")
collateral$GU_ID[fix] <- candidate[fix]
collateral$value <- parse_number(collateral$COLLATERAL)
collateral$value_invalid <- is.na(collateral$value) | collateral$value < 0
collateral$key_valid <- valid_id(collateral$GU_ID, "^[A-Z][0-9]{6}$")
check("collateral", "Missing, invalid or negative collateral value", collateral$value_invalid,
      "Flag and retain", "Keep original; invalid valuation becomes NA, never a recovery")
collateral$value[collateral$value_invalid | !collateral$key_valid] <- NA_real_
contracts$key_valid <- valid_id(contracts$IP_ID, "^[A-Z]{3}[0-9]{3}$") &
                       valid_id(contracts$AR_ID, "^[0-9]{8}$")
bad_contract_key <- duplicated(contracts$AR_ID) | duplicated(contracts$AR_ID, fromLast = TRUE)
bad_guarantee_key <- duplicated(collateral$GU_ID) | duplicated(collateral$GU_ID, fromLast = TRUE)
check("contracts", "Duplicate arrangement master key", bad_contract_key, "Stop and investigate", "Duplicate loan master keys make the join ambiguous")
check("collateral", "Duplicate guarantee key after repair", bad_guarantee_key, "Stop and investigate", "Duplicate guarantee keys make the join ambiguous")
if (any(bad_contract_key) || any(bad_guarantee_key)) {
  print(quality[quality$count > 0, ], row.names = FALSE)
  stop("Duplicate master keys: inspect the quality object; resolve them before joining.")
}
contracts$ASST_CLASS_original <- contracts$ASST_CLASS
unexpected_class <- !is.na(contracts$ASST_CLASS) & !contracts$ASST_CLASS %in% c("111", "112", "113")
check("contracts", "Unexpected asset class", unexpected_class, "Standardize", "Preserve the original code and label it Unknown")
check("contracts", "Missing asset class", is.na(contracts$ASST_CLASS), "Standardize", "Do not infer a missing loan category")
contracts$ASST_CLASS[is.na(contracts$ASST_CLASS) | unexpected_class] <- "Unknown"
contract_key <- paste(contracts$IP_ID, contracts$AR_ID, sep = "|")
i <- match(paste(standardized_defaults$IP_ID, standardized_defaults$AR_ID, sep = "|"), contract_key)
standardized_defaults$contract_match <- !is.na(i) & contracts$key_valid[i]
standardized_defaults$ASST_CLASS <- contracts$ASST_CLASS[i]
standardized_defaults$ASST_CLASS[is.na(standardized_defaults$ASST_CLASS)] <- "Unknown"
standardized_defaults$GU_ID <- contracts$GU_ID[i]
standardized_defaults$collateral_value <- collateral$value[match(standardized_defaults$GU_ID, collateral$GU_ID)]

check("contracts", "No guarantee recorded", is.na(contracts$GU_ID), "Flag and retain", "A guarantee link is optional")
check("contracts", "Guarantee has no valuation record",
      !is.na(contracts$GU_ID) & !contracts$GU_ID %in% collateral$GU_ID, "Flag and retain", "Valuation unavailable; it does not enter loss")
check("contracts", "Shared guarantee link", !is.na(contracts$GU_ID) &
      (duplicated(contracts$GU_ID) | duplicated(contracts$GU_ID, fromLast = TRUE)),
      "Flag and retain", "Shared collateral is non-additive and not cash")
check("defaults", "No matching borrower and contract", !standardized_defaults$contract_match, "Exclude from analysis", "No reliable borrower and contract match")

# 3. DEFAULT EPISODES 
standardized_defaults$event_id <- paste(standardized_defaults$IP_ID, standardized_defaults$AR_ID, standardized_defaults$DFLT_EFF_DT, sep = "|")
standardized_defaults$obligor_event_id <- paste(standardized_defaults$IP_ID, standardized_defaults$DFLT_EFF_DT, sep = "|")
duplicate_event <- duplicated(standardized_defaults$event_id) | duplicated(standardized_defaults$event_id, fromLast = TRUE)
check("defaults", "Duplicate default episode key", duplicate_event, "Stop and investigate", "Repeated episode keys need source clarification")
if (any(duplicate_event)) {
  print(quality[quality$count > 0, ], row.names = FALSE)
  stop("Duplicate IP_ID + AR_ID + DFLT_EFF_DT: inspect the quality object.")
}
standardized_defaults$key_valid <- valid_id(standardized_defaults$IP_ID, "^[A-Z]{3}[0-9]{3}$") & valid_id(standardized_defaults$AR_ID, "^[0-9]{8}$")
standardized_defaults$EAD_original <- standardized_defaults$EAD
standardized_defaults$EAD <- parse_number(standardized_defaults$EAD)
standardized_defaults$EAD_invalid <- is.na(standardized_defaults$EAD) | standardized_defaults$EAD <= 0
standardized_defaults$start <- parse_date(standardized_defaults$DFLT_EFF_DT)
sentinel <- !is.na(standardized_defaults$DFLT_END_DT) & standardized_defaults$DFLT_END_DT == "9999-12-31"
standardized_defaults$end <- parse_date(ifelse(sentinel, NA, standardized_defaults$DFLT_END_DT))
standardized_defaults$date_valid <- !is.na(standardized_defaults$start) & (sentinel | !is.na(standardized_defaults$end)) &
                     (sentinel | (!is.na(standardized_defaults$end) & standardized_defaults$end >= standardized_defaults$start))
standardized_defaults$closed <- !sentinel & !is.na(standardized_defaults$end) & standardized_defaults$end <= AS_OF_DATE
# Baseline includes both default endpoints, open periods end at the assumed cutoff.
standardized_defaults$window_end <- standardized_defaults$end
standardized_defaults$window_end[is.na(standardized_defaults$window_end) | standardized_defaults$window_end > AS_OF_DATE] <- AS_OF_DATE
standardized_defaults$overlap <- FALSE

for (rows in split(seq_len(nrow(standardized_defaults)), standardized_defaults$AR_ID)) {
  if (length(rows) < 2) next
  pairs <- combn(rows, 2)
  overlap <- standardized_defaults$start[pairs[1, ]] <= standardized_defaults$window_end[pairs[2, ]] &
             standardized_defaults$start[pairs[2, ]] <= standardized_defaults$window_end[pairs[1, ]]
  if (any(overlap, na.rm = TRUE)) standardized_defaults$overlap[rows] <- TRUE
}
check("defaults", "Repeated arrangement: all affected episodes",
      duplicated(standardized_defaults$AR_ID) | duplicated(standardized_defaults$AR_ID, fromLast = TRUE), "Flag and retain", "Separate defaults by their start dates")
check("defaults", "Overlapping default history", standardized_defaults$overlap, "Exclude from analysis", "Overlapping histories make attribution uncertain")
check("defaults", "Missing, invalid or nonpositive EAD", standardized_defaults$EAD_invalid, "Exclude from analysis", "Exposure is missing, invalid or nonpositive")
check("defaults", "Invalid default dates", !standardized_defaults$date_valid, "Exclude from analysis", "Invalid dates cannot define a default window")
check("defaults", "Default starts after cutoff", !is.na(standardized_defaults$start) & standardized_defaults$start > AS_OF_DATE, "Exclude from analysis", "Default starts after the observation date")
check("defaults", "Missing default reason", is.na(standardized_defaults$DFLT_RSN), "Flag and retain", "Reason is not needed for the loss calculation")
expected_level <- ifelse(standardized_defaults$ASST_CLASS == "113", "Arrangement", "Obligor")
check("defaults", "Default level disagrees with known class",
      standardized_defaults$ASST_CLASS != "Unknown" & standardized_defaults$DFLT_LVL != expected_level, "Flag and retain", "Do not force dates or default levels to agree")

# 4. TRANSACTIONS AND DATE MATCHING 
flow_names <- c("cashflows", "sale", "costs", "interest", "write_off")
expected_types <- list(cashflows = "recovery", sale = "sale of collateral",
                       costs = c("legal", "sale"), interest = "interest", write_off = "write-off")

standardized_cashflows <- data.frame()
for (name in flow_names) {
  x <- raw[[name]]
  x$source <- name
  x$source_row <- seq_len(nrow(x))
  x$AR_ID_original <- x$AR_ID
  x$duplicate_copy <- duplicated(raw[[name]])
  if (name == "sale") {
    candidate <- substring(x$AR_ID, 3)
    fix <- valid_id(x$AR_ID, "^00[0-9]{8}$") & candidate %in% contracts$AR_ID
    repair_examples <- rbind(repair_examples, data.frame(file = "sale", corrected_rows = sum(fix),
      original = x$AR_ID[fix][1], corrected = candidate[fix][1]))
    x$AR_ID[fix] <- candidate[fix]
  }
  x$amount <- parse_number(x$CF)
  x$date <- parse_date(x$CF_DT)
  x$amount_invalid <- is.na(x$amount)
  x$date_invalid <- is.na(x$date)
  x$type_valid <- x$CF_TP %in% expected_types[[name]]
  check(name, "Later exact duplicate copies", x$duplicate_copy,
        "Flag and retain", "No transaction ID proves an exact copy is an error")
  check(name, "Missing or invalid amount", x$amount_invalid, "Exclude from analysis", "Keep CF; an assigned missing amount makes the outcome unknown")
  check(name, "Negative amount", !is.na(x$amount) & x$amount < 0, "Flag and retain", "Sign is unverified; retain as supplied pending confirmation")
  check(name, "Invalid date or unexpected flow type", is.na(x$date) | !x$type_valid, "Exclude from analysis", "Invalid date/type prevents reliable attribution")
  check(name, "Cash flow after observation cutoff", !is.na(x$date) & x$date > AS_OF_DATE, "Exclude from analysis", "Transaction occurs after the observation date")
  check(name, "Unmatched arrangement after repair", !x$AR_ID %in% contracts$AR_ID, "Exclude from analysis", "Keep the source row without assigning it to a default")
  standardized_cashflows <- rbind(standardized_cashflows, x)
}
standardized_cashflows$flow_id <- seq_len(nrow(standardized_cashflows))


candidates <- merge(standardized_cashflows[c("flow_id", "AR_ID", "date", "source")],
                    standardized_defaults[standardized_defaults$date_valid & standardized_defaults$key_valid,
                           c("AR_ID", "event_id", "start", "window_end")], by = "AR_ID")
assign_episode <- function(candidates, upper_bound) {
  hit <- !is.na(candidates$date) & !is.na(candidates$start) &
         candidates$date >= candidates$start & candidates$date <= upper_bound &
         candidates$date <= AS_OF_DATE
  matches <- candidates[which(hit), ]
  multiple <- duplicated(matches$flow_id) | duplicated(matches$flow_id, fromLast = TRUE)
  unique_matches <- matches[!multiple, ]
  id <- unique_matches$event_id[match(standardized_cashflows$flow_id, unique_matches$flow_id)]
  id[!standardized_cashflows$type_valid] <- NA_character_
  status <- ifelse(is.na(id), "outside_window", "assigned")
  status[standardized_cashflows$flow_id %in% matches$flow_id[multiple]] <- "ambiguous_episode"
  status[!standardized_cashflows$AR_ID %in% standardized_defaults$AR_ID] <- "unmatched_arrangement"
  status[!is.na(standardized_cashflows$date) & standardized_cashflows$date > AS_OF_DATE] <- "after_cutoff"
  status[is.na(standardized_cashflows$date) | !standardized_cashflows$type_valid] <- "invalid_date_or_type"
  data.frame(event_id = id, status = status)
}
assignment <- assign_episode(candidates, candidates$window_end)
standardized_cashflows$event_id <- assignment$event_id
standardized_cashflows$match_status <- assignment$status
for (name in flow_names) check(name, "Outside default window",
  standardized_cashflows$match_status[standardized_cashflows$source == name] == "outside_window", "Exclude from analysis", "Outside baseline dates; test the through-cutoff rule")

# 5. LOSS CALCULATION 
total_flow <- function(type, assignment_column = "event_id") {
  keep <- standardized_cashflows$source == type & !is.na(standardized_cashflows[[assignment_column]])
  x <- standardized_cashflows[keep, ]
  if (!nrow(x)) return(rep(0, nrow(standardized_defaults)))
  sums <- sapply(split(x$amount, x[[assignment_column]]), sum)
  result <- rep(0, nrow(standardized_defaults))
  i <- match(standardized_defaults$event_id, names(sums))
  result[!is.na(i)] <- sums[i[!is.na(i)]]
  result
}
for (name in flow_names) standardized_defaults[[name]] <- total_flow(name)
standardized_defaults$loss <- with(standardized_defaults, EAD + costs + interest - cashflows - sale)
standardized_defaults$loss_rate <- with(standardized_defaults,
  ifelse(!is.na(EAD) & EAD > 0, loss/EAD, NA_real_))
# Write-offs cancel uncollectible debt, adding them would count that debt twice
# Use sale cash, not collateral valuations, no separate drawings data was supplied
unattributable <- is.na(standardized_cashflows$date) | !standardized_cashflows$type_valid

standardized_defaults$unattributable_flow_on_arrangement <- standardized_defaults$AR_ID %in% standardized_cashflows$AR_ID[unattributable]
standardized_defaults$base_valid <- with(standardized_defaults,
  key_valid & contract_match & date_valid & start <= AS_OF_DATE &
  !overlap & !is.na(EAD) & EAD > 0 & !is.na(loss))
standardized_defaults$base_valid <- standardized_defaults$base_valid & !standardized_defaults$unattributable_flow_on_arrangement
check("defaults", "Arrangement has invalid flow date or type", standardized_defaults$unattributable_flow_on_arrangement,
      "Exclude from analysis", "Conservative: quarantine every episode on this loan pending source clarification")
standardized_defaults$eligible_closed <- standardized_defaults$base_valid & standardized_defaults$closed
check("defaults", "Missing assigned loss-flow amount", is.na(standardized_defaults$cashflows) | is.na(standardized_defaults$costs) |
      is.na(standardized_defaults$interest) | is.na(standardized_defaults$sale), "Exclude from analysis", "An assigned loss component is unknown")
check("defaults", "Negative loss rate", !is.na(standardized_defaults$loss_rate) & standardized_defaults$loss_rate < 0, "Flag and retain", "Do not force a negative result to zero")
check("defaults", "Loss rate above 100%", !is.na(standardized_defaults$loss_rate) & standardized_defaults$loss_rate > 1, "Flag and retain", "Investigate timing and signs; do not cap at 100%")
check("defaults", "Absolute costs exceed EAD", !is.na(standardized_defaults$costs) & !is.na(standardized_defaults$EAD) &
      abs(standardized_defaults$costs) > standardized_defaults$EAD, "Flag and retain", "Investigate units and magnitude; do not invent corrections")
standardized_defaults$status <- ifelse(standardized_defaults$closed, "Closed", "Open")
standardized_defaults$start_year <- format(standardized_defaults$start, "%Y")
standardized_defaults$end_year <- ifelse(standardized_defaults$closed, format(standardized_defaults$end, "%Y"), "Open")
standardized_defaults$duration_years <- as.numeric(standardized_defaults$window_end - standardized_defaults$start)/365.25
standardized_defaults$duration_band <- cut(standardized_defaults$duration_years, c(0, 1, 2, 3, 5, Inf), right = FALSE,
                           labels = c("0 to <1", "1 to <2", "2 to <3", "3 to <5", "5+"))
closed <- standardized_defaults[standardized_defaults$eligible_closed, ]
stopifnot(nrow(closed) > 0, nrow(standardized_defaults) == nrow(raw$defaults),
          nrow(standardized_cashflows) == sum(sapply(raw[flow_names], nrow)))

# 6. SUMMARY TABLES / COMPARISON 
stats <- function(x) data.frame(n = nrow(x), EAD = sum(x$EAD), loss = sum(x$loss),
  weighted_rate_pct = 100*sum(x$loss)/sum(x$EAD), mean_rate_pct = 100*mean(x$loss_rate))
summaries <- cbind(dimension = "population", group = "Eligible closed episodes", stats(closed))
dimensions <- c("ASST_CLASS", "start_year", "end_year", "duration_band")
for (dimension in dimensions) {
  for (group in unique(as.character(closed[[dimension]]))) {
    subset <- closed[as.character(closed[[dimension]]) == group, ]
    summaries <- rbind(summaries, cbind(dimension, group, stats(subset)))
  }
}

obligor_events <- do.call(rbind, lapply(split(closed, closed$obligor_event_id), function(x)
  data.frame(obligor_event_id = x$obligor_event_id[1], IP_ID = x$IP_ID[1],
    DFLT_EFF_DT = x$DFLT_EFF_DT[1], n_arrangements = length(unique(x$AR_ID)),
    EAD = sum(x$EAD), loss = sum(x$loss))))
rownames(obligor_events) <- NULL
obligor_events$loss_rate <- obligor_events$loss/obligor_events$EAD
obligor_events$complete_event <- tapply(standardized_defaults$eligible_closed, standardized_defaults$obligor_event_id, all)[obligor_events$obligor_event_id]
summaries <- rbind(summaries,
  cbind(dimension = "unit_comparison", group = "Obligor + default start date: identical sample", stats(obligor_events)),
  cbind(dimension = "unit_comparison", group = "Arrangement episode: identical sample", stats(closed)))
stopifnot(abs(sum(obligor_events$loss)/sum(obligor_events$EAD) - sum(closed$loss)/sum(closed$EAD)) < 1e-10)

# 7. ONE TIMING SENSITIVITY (THROUGH CUTOFF, BEFORE THE NEXT DEFAULT) 
# Later payments may include normal repayments even after recovery, not just recoveries
# Extend payments, sales and costs, while interest/write-offs keep the default window
limit <- rep(AS_OF_DATE, nrow(standardized_defaults))
for (rows in split(seq_len(nrow(standardized_defaults)), standardized_defaults$AR_ID)) {
  for (row in rows) {
    starts <- standardized_defaults$start[rows]
    later <- starts[!is.na(starts) & starts > standardized_defaults$start[row]]
    later <- later[!is.na(later)]
    if (length(later)) limit[row] <- min(AS_OF_DATE, min(later) - 1)
  }
}
upper <- candidates$window_end
extend <- candidates$source %in% LATE_TYPES
upper[extend] <- limit[match(candidates$event_id[extend], standardized_defaults$event_id)]
a <- assign_episode(candidates, upper)
standardized_cashflows$event_id_late_cutoff <- a$event_id
standardized_cashflows$status_late_cutoff <- a$status
for (type in LATE_TYPES)
  standardized_defaults[[paste0(type, "_late")]] <- total_flow(type, "event_id_late_cutoff")
standardized_defaults$loss_late <- with(standardized_defaults,
  EAD + costs_late + interest - cashflows_late - sale_late)
standardized_defaults$loss_rate_late <- with(standardized_defaults,
  ifelse(!EAD_invalid, loss_late/EAD, NA_real_))
standardized_defaults$eligible_late <- standardized_defaults$eligible_closed & !is.na(standardized_defaults$loss_late)
check("defaults", "Costs exceed EAD under alternative timing",
  !is.na(standardized_defaults$costs_late) & !standardized_defaults$EAD_invalid & abs(standardized_defaults$costs_late) > standardized_defaults$EAD,
  "Flag and retain", "Late costs also require magnitude and unit checks")
closed <- standardized_defaults[standardized_defaults$eligible_closed, ]
matched <- standardized_defaults[standardized_defaults$eligible_late, ]
sensitivity <- data.frame()
for (group in c("All", sort(unique(closed$ASST_CLASS)))) {
  b <- if (group == "All") closed else closed[closed$ASST_CLASS == group, ]
  x <- if (group == "All") matched else matched[matched$ASST_CLASS == group, ]
  sensitivity <- rbind(sensitivity, data.frame(asset_class = group, baseline_n = nrow(b),
    matched_n = nrow(x), excluded_n = nrow(b) - nrow(x), matched_EAD = sum(x$EAD),
    EAD_coverage_pct = 100*sum(x$EAD)/sum(b$EAD),
    baseline_rate_pct = if (nrow(x)) 100*sum(x$loss)/sum(x$EAD) else NA_real_,
    late_rate_pct = if (nrow(x)) 100*sum(x$loss_late)/sum(x$EAD) else NA_real_))
}

high <- closed[closed$loss_rate > 1, ]
above_100 <- c(cases = nrow(high), share_pct = 100*nrow(high)/nrow(closed),
  no_net_collections = sum(high$cashflows == 0 & high$sale == 0),
  within_101 = sum(high$loss_rate <= 1.01), above_150 = sum(closed$loss_rate > 1.5),
  negative_rates = sum(closed$loss_rate < 0))
mortgages <- matched[matched$ASST_CLASS == "113", ]


stopifnot(!anyDuplicated(standardized_cashflows$flow_id))
for (type in flow_names) {
  transactions <- standardized_cashflows[standardized_cashflows$source == type, ]
  stopifnot(identical(sort(transactions$source_row), seq_len(nrow(raw[[type]]))))
  for (assignment_column in c("event_id", "event_id_late_cutoff")) {
    assigned <- !is.na(transactions[[assignment_column]])
    stopifnot(all(transactions[[assignment_column]][assigned] %in% standardized_defaults$event_id),
      abs(sum(parse_number(raw[[type]]$CF), na.rm = TRUE) -
          sum(transactions$amount[assigned], na.rm = TRUE) -
          sum(transactions$amount[!assigned], na.rm = TRUE)) < .01)
  }
}

# 8. EXPORTING
write.csv(standardized_defaults, file.path(OUTPUT_FOLDER, "standardized_defaults.csv"), row.names = FALSE, na = "")
write.csv(standardized_cashflows, file.path(OUTPUT_FOLDER, "standardized_cashflows.csv"), row.names = FALSE, na = "")
png(file.path(OUTPUT_FOLDER, "loss_charts.png"), width = 1800, height = 1200, res = 140)
par(mfrow = c(2, 2), mar = c(5, 6, 3, 1), las = 1)
plot_titles <- c(ASST_CLASS = "Loan category", start_year = "Year the default started",
                 end_year = "Year the default ended", duration_band = "Time in default (years)")
for (dimension in dimensions) {
  x <- summaries[summaries$dimension == dimension, ]
  x <- x[order(x$group), ]
  labels <- x$group
  if (dimension == "ASST_CLASS") labels <- c("111" = "Small business:\nnon-residential",
    "112" = "Small business:\nother loans", "113" = "Individuals:\nhome loans", "Unknown" = "Unknown")[labels]
  bars <- barplot(x$weighted_rate_pct, names.arg = labels, col = "#006400", border = NA,
          ylab = "EAD-weighted calculated loss (%)", cex.lab = 0.9,
          main = plot_titles[[dimension]], cex.names = 0.85,
          ylim = c(0, max(110, x$weighted_rate_pct*1.15)))
  abline(h = 100, lty = 3, col = "grey60")
  text(bars, x$weighted_rate_pct, labels = paste0("n=", format(x$n, big.mark = ",", trim = TRUE)),
       pos = 3, cex = 0.7)
}
dev.off()

